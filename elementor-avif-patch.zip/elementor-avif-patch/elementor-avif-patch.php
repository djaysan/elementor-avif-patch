<?php
/*
Plugin Name: WP Auto-Patch Elementor AVIF
Description: Automatically patches Elementor's frontend.js to support .avif in lightbox.
Author: Ludovic Verbeeck
Version: 1.0
*/

add_action('init', function () {
    $plugin_path = WP_PLUGIN_DIR . '/elementor/assets/js/frontend.js';
    $plugin_min_path = WP_PLUGIN_DIR . '/elementor/assets/js/frontend.min.js';

    if (file_exists($plugin_path)) {
        $contents = file_get_contents($plugin_path);
        if (strpos($contents, '|avif') === false) {
            $patched = preg_replace('/svg\|webp/', 'svg|webp|avif', $contents);
            file_put_contents($plugin_path, $patched);
        }
    }

    if (file_exists($plugin_min_path)) {
        $min_contents = file_get_contents($plugin_min_path);
        if (strpos($min_contents, '|avif') === false) {
            $patched_min = preg_replace('/svg\|webp/', 'svg|webp|avif', $min_contents);
            file_put_contents($plugin_min_path, $patched_min);
        }
    }
});

// Optional: Admin notice if Elementor is updated (based on file modified time)
add_action('admin_notices', function () {
    $plugin_path = WP_PLUGIN_DIR . '/elementor/assets/js/frontend.js';
    if (file_exists($plugin_path)) {
        $last_modified = filemtime($plugin_path);
        $last_checked = get_option('elementor_avif_patch_last_checked', 0);
        if ($last_modified > $last_checked) {
            update_option('elementor_avif_patch_last_checked', time());
            echo '<div class="notice notice-success is-dismissible"><p><strong>Elementor AVIF patch re-applied.</strong> Lightbox now supports .avif images again.</p></div>';
        }
    }
});
?>
